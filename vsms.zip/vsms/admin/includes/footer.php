   <footer class="footer">
                    <?php echo date('Y');?> © Vehicle Service Managment System
                </footer>
